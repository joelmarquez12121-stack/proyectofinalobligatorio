package respondapp;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class Conexion {
    public static Connection abrir() throws Exception {
        Properties datos = new Properties();
        Path archivo = Path.of(System.getProperty("respondapp.config", "config.properties"));
        if (!Files.exists(archivo)) throw new Exception("No se encontro config.properties. Ejecute desde la carpeta del proyecto.");
        try (InputStream entrada = Files.newInputStream(archivo)) { datos.load(entrada); }
        return DriverManager.getConnection(datos.getProperty("db.url"), datos.getProperty("db.usuario"), datos.getProperty("db.clave"));
    }
}
