package respondapp;

import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

// Pequeñas ayudas compartidas por los formularios.
public class Pantalla {
    public static void error(java.awt.Component ventana, Exception ex) {
        String mensaje = ex.getMessage();
        if (ex instanceof SQLException) {
            SQLException sql = (SQLException) ex;
            if (sql.getErrorCode() == 1062) mensaje = "Ese usuario, nombre o registro ya existe.";
            else if (sql.getErrorCode() == 1451) mensaje = "No se puede eliminar: hay preguntas o datos relacionados.";
            else if (sql.getErrorCode() == 1049) mensaje = "Falta la base de datos. Importe 01_estructura.sql y 02_datos.sql en Workbench.";
            else if (sql.getSQLState() != null && sql.getSQLState().startsWith("08")) mensaje = "No se pudo conectar. Inicie MySQL en XAMPP y revise el puerto de config.properties.";
        }
        JOptionPane.showMessageDialog(ventana, mensaje, "Revisar datos", JOptionPane.WARNING_MESSAGE);
    }
    public static int id(JComboBox<Item> combo) throws Exception {
        if (combo.getSelectedItem() == null) throw new Exception("No hay elementos disponibles para seleccionar.");
        return ((Item) combo.getSelectedItem()).id;
    }
    public static void seleccionar(JComboBox<Item> combo, int id) {
        for (int i = 0; i < combo.getItemCount(); i++) if (combo.getItemAt(i).id == id) { combo.setSelectedIndex(i); return; }
    }
}
