package respondapp;

import javax.swing.JOptionPane;

public class Categorias extends javax.swing.JFrame {
    private Usuario sesion;
    private int idSeleccionado=0;

    public Categorias(Usuario sesion) {
        initComponents();
        setLocationRelativeTo(null);
        this.sesion=sesion;
        tblCategorias.getSelectionModel().addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) { seleccionar(); }
        });
        try { actualizar(); } catch(Exception ex) { Pantalla.error(this,ex); }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        lblDescripcion = new javax.swing.JLabel();
        txtDescripcion = new javax.swing.JTextField();
        btnNueva = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();
        lblAyuda = new javax.swing.JLabel();
        scrolltblCategorias = new javax.swing.JScrollPane();
        tblCategorias = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("RespondApp - Categorias");
        setPreferredSize(new java.awt.Dimension(730, 530));
        setResizable(false);
        getContentPane().setLayout(null);

        lblNombre.setText("Nombre");
        getContentPane().add(lblNombre);
        lblNombre.setBounds(25, 25, 160, 25);
        getContentPane().add(txtNombre);
        txtNombre.setBounds(190, 25, 470, 28);

        lblDescripcion.setText("Descripcion");
        getContentPane().add(lblDescripcion);
        lblDescripcion.setBounds(25, 70, 160, 25);
        getContentPane().add(txtDescripcion);
        txtDescripcion.setBounds(190, 70, 470, 28);

        btnNueva.setText("Nueva");
        btnNueva.addActionListener(this::btnNuevaActionPerformed);
        getContentPane().add(btnNueva);
        btnNueva.setBounds(25, 115, 115, 32);

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);
        getContentPane().add(btnGuardar);
        btnGuardar.setBounds(155, 115, 115, 32);

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(this::btnEliminarActionPerformed);
        getContentPane().add(btnEliminar);
        btnEliminar.setBounds(285, 115, 115, 32);

        btnCerrar.setText("Cerrar");
        btnCerrar.addActionListener(this::btnCerrarActionPerformed);
        getContentPane().add(btnCerrar);
        btnCerrar.setBounds(415, 115, 115, 32);

        lblAyuda.setText("Seleccione una fila para modificar. Nueva limpia los campos.");
        getContentPane().add(lblAyuda);
        lblAyuda.setBounds(25, 165, 650, 25);

        tblCategorias.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        scrolltblCategorias.setViewportView(tblCategorias);

        getContentPane().add(scrolltblCategorias);
        scrolltblCategorias.setBounds(25, 200, 650, 245);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuevaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevaActionPerformed
        limpiar();
    }//GEN-LAST:event_btnNuevaActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        try { Datos.categoriaGuardar(sesion,idSeleccionado,txtNombre.getText(),txtDescripcion.getText()); actualizar(); limpiar(); JOptionPane.showMessageDialog(this,"Categoria guardada."); }
        catch(Exception ex) { Pantalla.error(this,ex); }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        if(idSeleccionado==0) { JOptionPane.showMessageDialog(this,"Seleccione una categoria."); return; }
        if(JOptionPane.showConfirmDialog(this,"¿Eliminar la categoria seleccionada?","Eliminar",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION) return;
        try { Datos.categoriaEliminar(sesion,idSeleccionado); actualizar(); limpiar(); }
        catch(Exception ex) { Pantalla.error(this,ex); }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        dispose();
    }//GEN-LAST:event_btnCerrarActionPerformed

    private void actualizar() throws Exception { tblCategorias.setModel(Datos.categoriasTabla(sesion)); }
    private void limpiar() { idSeleccionado=0; txtNombre.setText(""); txtDescripcion.setText(""); tblCategorias.clearSelection(); }
    private void seleccionar() {
        int fila=tblCategorias.getSelectedRow(); if(fila<0) return;
        idSeleccionado=((Number)tblCategorias.getValueAt(fila,0)).intValue();
        txtNombre.setText(tblCategorias.getValueAt(fila,1).toString()); txtDescripcion.setText(tblCategorias.getValueAt(fila,2).toString());
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnNueva;
    private javax.swing.JLabel lblAyuda;
    private javax.swing.JLabel lblDescripcion;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JScrollPane scrolltblCategorias;
    private javax.swing.JTable tblCategorias;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
