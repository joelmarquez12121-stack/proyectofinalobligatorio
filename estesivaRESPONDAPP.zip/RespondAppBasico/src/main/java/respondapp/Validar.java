package respondapp;

import java.time.LocalDate;

public class Validar {
    public static String texto(String valor, String campo, int maximo) throws Exception {
        valor = valor.trim();
        if (valor.isEmpty() || valor.length() > maximo) throw new Exception(campo + ": complete entre 1 y " + maximo + " caracteres.");
        return valor;
    }
    public static String fecha(String valor) throws Exception {
        try {
            LocalDate fecha = LocalDate.parse(valor.trim());
            if (fecha.isAfter(LocalDate.now()) || fecha.isBefore(LocalDate.of(1900, 1, 1))) throw new Exception();
            return fecha.toString();
        } catch (Exception ex) { throw new Exception("Fecha de nacimiento invalida. Use AAAA-MM-DD, por ejemplo 2008-05-21."); }
    }
    public static String email(String valor) throws Exception {
        valor = texto(valor, "Email", 150);
        if (!valor.matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+")) throw new Exception("Escriba un email valido.");
        return valor;
    }
    public static void clave(char[] valor) throws Exception {
        if (valor.length < 4 || valor.length > 100) throw new Exception("La clave debe tener entre 4 y 100 caracteres.");
    }
}
