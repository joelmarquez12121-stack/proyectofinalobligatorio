package respondapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    public static Connection abrir() throws SQLException {
        // Cambiar estos datos si el servidor MySQL tiene otra configuracion.
        String url = "jdbc:mysql://127.0.0.1:3306/respondapp_basico?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=America/Montevideo&connectTimeout=3000&socketTimeout=10000";
        String usuario = "root";
        String clave = "";

        return DriverManager.getConnection(url, usuario, clave);
    }
}
