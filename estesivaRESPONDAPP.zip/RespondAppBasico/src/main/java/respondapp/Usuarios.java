package respondapp;

import javax.swing.JOptionPane;

public class Usuarios extends javax.swing.JFrame {
    private Usuario sesion;

    public Usuarios(Usuario sesion) {
        initComponents();
        setLocationRelativeTo(null);
        this.sesion=sesion;
        try { Datos.administrador(sesion); actualizar(); } catch(Exception ex) { Pantalla.error(this,ex); dispose(); }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        lblUsuario = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        lblFecha = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        lblClave = new javax.swing.JLabel();
        txtClave = new javax.swing.JPasswordField();
        lblRol = new javax.swing.JLabel();
        cmbRol = new javax.swing.JComboBox<>();
        btnGuardar = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();
        scrolltblUsuarios = new javax.swing.JScrollPane();
        tblUsuarios = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("RespondApp - Crear usuarios");
        setPreferredSize(new java.awt.Dimension(710, 610));
        setResizable(false);
        getContentPane().setLayout(null);

        lblNombre.setText("Nombre completo");
        getContentPane().add(lblNombre);
        lblNombre.setBounds(25, 25, 160, 25);
        getContentPane().add(txtNombre);
        txtNombre.setBounds(190, 25, 460, 28);

        lblUsuario.setText("Nombre de usuario");
        getContentPane().add(lblUsuario);
        lblUsuario.setBounds(25, 65, 160, 25);
        getContentPane().add(txtUsuario);
        txtUsuario.setBounds(190, 65, 460, 28);

        lblFecha.setText("Nacimiento AAAA-MM-DD");
        getContentPane().add(lblFecha);
        lblFecha.setBounds(25, 105, 160, 25);
        getContentPane().add(txtFecha);
        txtFecha.setBounds(190, 105, 460, 28);

        lblEmail.setText("Email");
        getContentPane().add(lblEmail);
        lblEmail.setBounds(25, 145, 160, 25);
        getContentPane().add(txtEmail);
        txtEmail.setBounds(190, 145, 460, 28);

        lblClave.setText("Clave (4 a 100 caracteres)");
        getContentPane().add(lblClave);
        lblClave.setBounds(25, 185, 160, 25);
        getContentPane().add(txtClave);
        txtClave.setBounds(190, 185, 460, 28);

        lblRol.setText("Rol");
        getContentPane().add(lblRol);
        lblRol.setBounds(25, 225, 160, 25);

        cmbRol.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "JUGADOR", "ADMINISTRADOR" }));
        getContentPane().add(cmbRol);
        cmbRol.setBounds(190, 225, 460, 28);

        btnGuardar.setText("Crear usuario");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);
        getContentPane().add(btnGuardar);
        btnGuardar.setBounds(190, 270, 145, 32);

        btnCerrar.setText("Cerrar");
        btnCerrar.addActionListener(this::btnCerrarActionPerformed);
        getContentPane().add(btnCerrar);
        btnCerrar.setBounds(350, 270, 145, 32);

        tblUsuarios.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        scrolltblUsuarios.setViewportView(tblUsuarios);

        getContentPane().add(scrolltblUsuarios);
        scrolltblUsuarios.setBounds(25, 325, 635, 210);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        char[] clave=txtClave.getPassword();
        try {
            Datos.crearUsuario(sesion,txtNombre.getText(),txtUsuario.getText(),txtFecha.getText(),txtEmail.getText(),clave,(String)cmbRol.getSelectedItem());
            actualizar(); txtNombre.setText(""); txtUsuario.setText(""); txtFecha.setText(""); txtEmail.setText("");
            JOptionPane.showMessageDialog(this,"Usuario creado.");
        } catch(Exception ex) { Pantalla.error(this,ex); }
        finally { java.util.Arrays.fill(clave,'\0'); txtClave.setText(""); }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        dispose();
    }//GEN-LAST:event_btnCerrarActionPerformed

    private void actualizar() throws Exception { tblUsuarios.setModel(Datos.usuariosTabla(sesion)); }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JComboBox<String> cmbRol;
    private javax.swing.JLabel lblClave;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblFecha;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblRol;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JScrollPane scrolltblUsuarios;
    private javax.swing.JTable tblUsuarios;
    private javax.swing.JPasswordField txtClave;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
