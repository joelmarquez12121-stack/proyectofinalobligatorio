package respondapp;

import javax.swing.JOptionPane;

public class Juego extends javax.swing.JFrame {
    private Usuario sesion;
    private int partida;
    private Datos.Estado estado;
    private Datos.PreguntaDatos pregunta;

    public Juego(Usuario sesion) {
        initComponents();
        setLocationRelativeTo(null);
        this.sesion=sesion; btnResponder.setEnabled(false);
        try { for(Item i:Datos.categorias()) cmbCategoria.addItem(i); } catch(Exception ex) { Pantalla.error(this,ex); }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblPartida = new javax.swing.JLabel();
        lblTurno = new javax.swing.JLabel();
        lblPuntos = new javax.swing.JLabel();
        lblCategoria = new javax.swing.JLabel();
        cmbCategoria = new javax.swing.JComboBox<>();
        btnSortear = new javax.swing.JButton();
        txtPregunta = new javax.swing.JTextArea();
        cmbRespuesta = new javax.swing.JComboBox<>();
        btnResponder = new javax.swing.JButton();
        lblResultado = new javax.swing.JTextArea();
        btnCerrar = new javax.swing.JButton();
        lblAyuda = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("RespondApp - Partida");
        setPreferredSize(new java.awt.Dimension(900, 650));
        setResizable(false);
        getContentPane().setLayout(null);

        lblPartida.setText("Partida");
        getContentPane().add(lblPartida);
        lblPartida.setBounds(25, 15, 820, 25);

        lblTurno.setText("Turno");
        getContentPane().add(lblTurno);
        lblTurno.setBounds(25, 45, 820, 25);

        lblPuntos.setText("Puntos");
        getContentPane().add(lblPuntos);
        lblPuntos.setBounds(25, 75, 820, 25);

        lblCategoria.setText("Categoria");
        getContentPane().add(lblCategoria);
        lblCategoria.setBounds(25, 120, 120, 25);
        getContentPane().add(cmbCategoria);
        cmbCategoria.setBounds(150, 120, 430, 28);

        btnSortear.setText("Cargar pregunta");
        btnSortear.addActionListener(this::btnSortearActionPerformed);
        getContentPane().add(btnSortear);
        btnSortear.setBounds(600, 118, 230, 32);

        txtPregunta.setLineWrap(true);
        txtPregunta.setWrapStyleWord(true);
        txtPregunta.setEditable(false);
        txtPregunta.setFocusable(false);
        getContentPane().add(txtPregunta);
        txtPregunta.setBounds(25, 170, 805, 100);

        getContentPane().add(cmbRespuesta);
        cmbRespuesta.setBounds(25, 290, 805, 28);

        btnResponder.setText("Responder");
        btnResponder.addActionListener(this::btnResponderActionPerformed);
        getContentPane().add(btnResponder);
        btnResponder.setBounds(25, 340, 200, 32);

        lblResultado.setText("Seleccione una categoria y cargue una pregunta.");
        lblResultado.setLineWrap(true);
        lblResultado.setWrapStyleWord(true);
        lblResultado.setEditable(false);
        lblResultado.setFocusable(false);
        getContentPane().add(lblResultado);
        lblResultado.setBounds(25, 390, 805, 60);

        btnCerrar.setText("Guardar y volver al menu");
        btnCerrar.addActionListener(this::btnCerrarActionPerformed);
        getContentPane().add(btnCerrar);
        btnCerrar.setBounds(25, 455, 300, 32);

        lblAyuda.setText("La partida se guarda al responder. Puede cerrar y continuar mas tarde.");
        getContentPane().add(lblAyuda);
        lblAyuda.setBounds(25, 510, 805, 25);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSortearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSortearActionPerformed
        try {
            pregunta=Datos.sortear(sesion,partida,Pantalla.id(cmbCategoria));
            txtPregunta.setText(pregunta.texto+"\nDificultad: "+pregunta.dificultad);
            cmbRespuesta.removeAllItems(); for(int i=0;i<4;i++) cmbRespuesta.addItem((i+1)+". "+pregunta.opciones[i]);
            cmbRespuesta.setSelectedIndex(-1); btnResponder.setEnabled(true); btnSortear.setEnabled(false); cmbCategoria.setEnabled(false);
            lblResultado.setText("Seleccione una respuesta y pulse Responder.");
        } catch(Exception ex) { Pantalla.error(this,ex); }
    }//GEN-LAST:event_btnSortearActionPerformed

    private void btnResponderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResponderActionPerformed
        if(pregunta==null || cmbRespuesta.getSelectedIndex()<0) { JOptionPane.showMessageDialog(this,"Seleccione una de las cuatro respuestas."); return; }
        btnResponder.setEnabled(false);
        try {
            String resultado=Datos.responder(sesion,partida,estado.respondidas+1,pregunta.id,pregunta.opcionesId[cmbRespuesta.getSelectedIndex()]);
            pregunta=null; cmbRespuesta.removeAllItems(); txtPregunta.setText("");
            actualizar(); lblResultado.setText(resultado);
            JOptionPane.showMessageDialog(this,resultado);
        } catch(Exception ex) { btnResponder.setEnabled(true); Pantalla.error(this,ex); }
    }//GEN-LAST:event_btnResponderActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        dispose();
    }//GEN-LAST:event_btnCerrarActionPerformed

    public void abrir(int id) throws Exception { partida=id; actualizar(); }
    private void actualizar() throws Exception {
        estado=Datos.estado(sesion,partida);
        boolean terminada=estado.estado.equals("finalizada");
        lblPartida.setText("Partida "+partida+" | "+estado.estado+" | Rondas respondidas: "+estado.respondidas+" / "+estado.total);
        lblPuntos.setText(estado.nombre1+": "+estado.puntos1+" puntos     |     "+estado.nombre2+": "+estado.puntos2+" puntos");
        if(terminada) {
            String ganador=estado.puntos1==estado.puntos2 ? "Empate" : "Gano "+(estado.puntos1>estado.puntos2 ? estado.nombre1:estado.nombre2);
            lblTurno.setText("Partida finalizada. "+ganador+".");
        } else {
            String activo=estado.activo==estado.jugador1 ? estado.nombre1:estado.nombre2;
            String espera=estado.activo==estado.jugador1 ? estado.nombre2:estado.nombre1;
            lblTurno.setText("Ronda "+(estado.respondidas+1)+" | Activo: "+activo+" | En espera: "+espera);
        }
        btnSortear.setEnabled(!terminada); cmbCategoria.setEnabled(!terminada); btnResponder.setEnabled(false);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnResponder;
    private javax.swing.JButton btnSortear;
    private javax.swing.JComboBox<Item> cmbCategoria;
    private javax.swing.JComboBox<String> cmbRespuesta;
    private javax.swing.JLabel lblAyuda;
    private javax.swing.JLabel lblCategoria;
    private javax.swing.JLabel lblPartida;
    private javax.swing.JLabel lblPuntos;
    private javax.swing.JTextArea lblResultado;
    private javax.swing.JLabel lblTurno;
    private javax.swing.JTextArea txtPregunta;
    // End of variables declaration//GEN-END:variables
}
