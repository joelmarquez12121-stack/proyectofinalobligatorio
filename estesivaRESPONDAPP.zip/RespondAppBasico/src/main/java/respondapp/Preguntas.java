package respondapp;

import javax.swing.JOptionPane;

public class Preguntas extends javax.swing.JFrame {
    private Usuario sesion;
    private int idSeleccionado=0;

    public Preguntas(Usuario sesion) {
        initComponents();
        setLocationRelativeTo(null);
        this.sesion=sesion;
        tblPreguntas.getSelectionModel().addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) { seleccionar(); }
        });
        try { for(Item i:Datos.categorias()) cmbCategoria.addItem(i); actualizar(); }
        catch(Exception ex) { Pantalla.error(this,ex); }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblCategoria = new javax.swing.JLabel();
        cmbCategoria = new javax.swing.JComboBox<>();
        lblDificultad = new javax.swing.JLabel();
        cmbDificultad = new javax.swing.JComboBox<>();
        lblPregunta = new javax.swing.JLabel();
        txtPregunta = new javax.swing.JTextField();
        lblOpcion1 = new javax.swing.JLabel();
        txtOpcion1 = new javax.swing.JTextField();
        lblOpcion2 = new javax.swing.JLabel();
        txtOpcion2 = new javax.swing.JTextField();
        lblOpcion3 = new javax.swing.JLabel();
        txtOpcion3 = new javax.swing.JTextField();
        lblOpcion4 = new javax.swing.JLabel();
        txtOpcion4 = new javax.swing.JTextField();
        lblCorrecta = new javax.swing.JLabel();
        cmbCorrecta = new javax.swing.JComboBox<>();
        btnNueva = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();
        lblAyuda = new javax.swing.JLabel();
        scrolltblPreguntas = new javax.swing.JScrollPane();
        tblPreguntas = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("RespondApp - Preguntas y cuatro opciones");
        setPreferredSize(new java.awt.Dimension(860, 730));
        setResizable(false);
        getContentPane().setLayout(null);

        lblCategoria.setText("Categoria");
        getContentPane().add(lblCategoria);
        lblCategoria.setBounds(25, 20, 160, 25);
        getContentPane().add(cmbCategoria);
        cmbCategoria.setBounds(190, 20, 600, 28);

        lblDificultad.setText("Dificultad");
        getContentPane().add(lblDificultad);
        lblDificultad.setBounds(25, 60, 160, 25);

        cmbDificultad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "facil", "medio", "dificil" }));
        getContentPane().add(cmbDificultad);
        cmbDificultad.setBounds(190, 60, 600, 28);

        lblPregunta.setText("Pregunta (max. 500)");
        getContentPane().add(lblPregunta);
        lblPregunta.setBounds(25, 100, 160, 25);
        getContentPane().add(txtPregunta);
        txtPregunta.setBounds(190, 100, 600, 28);

        lblOpcion1.setText("Opcion 1");
        getContentPane().add(lblOpcion1);
        lblOpcion1.setBounds(25, 140, 160, 25);
        getContentPane().add(txtOpcion1);
        txtOpcion1.setBounds(190, 140, 600, 28);

        lblOpcion2.setText("Opcion 2");
        getContentPane().add(lblOpcion2);
        lblOpcion2.setBounds(25, 180, 160, 25);
        getContentPane().add(txtOpcion2);
        txtOpcion2.setBounds(190, 180, 600, 28);

        lblOpcion3.setText("Opcion 3");
        getContentPane().add(lblOpcion3);
        lblOpcion3.setBounds(25, 220, 160, 25);
        getContentPane().add(txtOpcion3);
        txtOpcion3.setBounds(190, 220, 600, 28);

        lblOpcion4.setText("Opcion 4");
        getContentPane().add(lblOpcion4);
        lblOpcion4.setBounds(25, 260, 160, 25);
        getContentPane().add(txtOpcion4);
        txtOpcion4.setBounds(190, 260, 600, 28);

        lblCorrecta.setText("Opcion correcta");
        getContentPane().add(lblCorrecta);
        lblCorrecta.setBounds(25, 300, 160, 25);

        cmbCorrecta.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4" }));
        getContentPane().add(cmbCorrecta);
        cmbCorrecta.setBounds(190, 300, 600, 28);

        btnNueva.setText("Nueva pregunta");
        btnNueva.addActionListener(this::btnNuevaActionPerformed);
        getContentPane().add(btnNueva);
        btnNueva.setBounds(25, 345, 180, 32);

        btnGuardar.setText("Guardar pregunta");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);
        getContentPane().add(btnGuardar);
        btnGuardar.setBounds(220, 345, 180, 32);

        btnCerrar.setText("Cerrar");
        btnCerrar.addActionListener(this::btnCerrarActionPerformed);
        getContentPane().add(btnCerrar);
        btnCerrar.setBounds(415, 345, 150, 32);

        lblAyuda.setText("Seleccione una fila para editar. Las respuestas anteriores conservan su historial.");
        getContentPane().add(lblAyuda);
        lblAyuda.setBounds(25, 390, 790, 25);

        tblPreguntas.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        scrolltblPreguntas.setViewportView(tblPreguntas);

        getContentPane().add(scrolltblPreguntas);
        scrolltblPreguntas.setBounds(25, 425, 770, 220);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuevaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevaActionPerformed
        idSeleccionado=0; tblPreguntas.clearSelection(); txtPregunta.setText(""); txtOpcion1.setText(""); txtOpcion2.setText(""); txtOpcion3.setText(""); txtOpcion4.setText(""); cmbCorrecta.setSelectedIndex(0);
    }//GEN-LAST:event_btnNuevaActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        try {
            String[] opciones={txtOpcion1.getText(),txtOpcion2.getText(),txtOpcion3.getText(),txtOpcion4.getText()};
            Datos.preguntaGuardar(sesion,idSeleccionado,Pantalla.id(cmbCategoria),txtPregunta.getText(),(String)cmbDificultad.getSelectedItem(),opciones,cmbCorrecta.getSelectedIndex());
            actualizar(); btnNuevaActionPerformed(evt); JOptionPane.showMessageDialog(this,"Pregunta guardada con cuatro opciones.");
        } catch(Exception ex) { Pantalla.error(this,ex); }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        dispose();
    }//GEN-LAST:event_btnCerrarActionPerformed

    private void actualizar() throws Exception { tblPreguntas.setModel(Datos.preguntasTabla(sesion)); }
    private void seleccionar() {
        int fila=tblPreguntas.getSelectedRow(); if(fila<0) return;
        try {
            idSeleccionado=((Number)tblPreguntas.getValueAt(fila,0)).intValue();
            Datos.PreguntaDatos p=Datos.preguntaLeer(sesion,idSeleccionado);
            Pantalla.seleccionar(cmbCategoria,p.categoria); cmbDificultad.setSelectedItem(p.dificultad); txtPregunta.setText(p.texto);
            txtOpcion1.setText(p.opciones[0]); txtOpcion2.setText(p.opciones[1]); txtOpcion3.setText(p.opciones[2]); txtOpcion4.setText(p.opciones[3]);
            for(int i=0;i<4;i++) if(p.opciones[i].equals(p.correcta)) cmbCorrecta.setSelectedIndex(i);
        } catch(Exception ex) { Pantalla.error(this,ex); }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnNueva;
    private javax.swing.JComboBox<Item> cmbCategoria;
    private javax.swing.JComboBox<String> cmbCorrecta;
    private javax.swing.JComboBox<String> cmbDificultad;
    private javax.swing.JLabel lblAyuda;
    private javax.swing.JLabel lblCategoria;
    private javax.swing.JLabel lblCorrecta;
    private javax.swing.JLabel lblDificultad;
    private javax.swing.JLabel lblOpcion1;
    private javax.swing.JLabel lblOpcion2;
    private javax.swing.JLabel lblOpcion3;
    private javax.swing.JLabel lblOpcion4;
    private javax.swing.JLabel lblPregunta;
    private javax.swing.JScrollPane scrolltblPreguntas;
    private javax.swing.JTable tblPreguntas;
    private javax.swing.JTextField txtOpcion1;
    private javax.swing.JTextField txtOpcion2;
    private javax.swing.JTextField txtOpcion3;
    private javax.swing.JTextField txtOpcion4;
    private javax.swing.JTextField txtPregunta;
    // End of variables declaration//GEN-END:variables
}
