package respondapp;

import javax.swing.JOptionPane;

public class Menu extends javax.swing.JFrame {
    private Usuario sesion;

    public Menu(Usuario sesion) {
        initComponents();
        setLocationRelativeTo(null);
        this.sesion=sesion;
        lblSesion.setText("Usuario: "+sesion.usuario+" | "+sesion.rol);
        btnUsuarios.setEnabled(sesion.esAdmin()); btnCategorias.setEnabled(sesion.esAdmin());
        btnPreguntas.setEnabled(sesion.esAdmin()); btnConsultas.setEnabled(sesion.esAdmin());
        btnPartida.setEnabled(!sesion.esAdmin()); btnPerfil.setEnabled(!sesion.esAdmin());
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblSesion = new javax.swing.JLabel();
        btnUsuarios = new javax.swing.JButton();
        btnCategorias = new javax.swing.JButton();
        btnPreguntas = new javax.swing.JButton();
        btnConsultas = new javax.swing.JButton();
        btnPartida = new javax.swing.JButton();
        btnPerfil = new javax.swing.JButton();
        btnRanking = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("RespondApp - Menu");
        setPreferredSize(new java.awt.Dimension(440, 510));
        setResizable(false);
        getContentPane().setLayout(null);

        lblSesion.setText("Sesion");
        getContentPane().add(lblSesion);
        lblSesion.setBounds(25, 20, 380, 25);

        btnUsuarios.setText("Crear usuarios");
        btnUsuarios.addActionListener(this::btnUsuariosActionPerformed);
        getContentPane().add(btnUsuarios);
        btnUsuarios.setBounds(40, 65, 340, 32);

        btnCategorias.setText("Categorias");
        btnCategorias.addActionListener(this::btnCategoriasActionPerformed);
        getContentPane().add(btnCategorias);
        btnCategorias.setBounds(40, 110, 340, 32);

        btnPreguntas.setText("Preguntas y respuestas");
        btnPreguntas.addActionListener(this::btnPreguntasActionPerformed);
        getContentPane().add(btnPreguntas);
        btnPreguntas.setBounds(40, 155, 340, 32);

        btnConsultas.setText("Consultas de base de datos");
        btnConsultas.addActionListener(this::btnConsultasActionPerformed);
        getContentPane().add(btnConsultas);
        btnConsultas.setBounds(40, 200, 340, 32);

        btnPartida.setText("Nueva partida / Continuar");
        btnPartida.addActionListener(this::btnPartidaActionPerformed);
        getContentPane().add(btnPartida);
        btnPartida.setBounds(40, 245, 340, 32);

        btnPerfil.setText("Mis datos personales");
        btnPerfil.addActionListener(this::btnPerfilActionPerformed);
        getContentPane().add(btnPerfil);
        btnPerfil.setBounds(40, 290, 340, 32);

        btnRanking.setText("Ranking por categoria");
        btnRanking.addActionListener(this::btnRankingActionPerformed);
        getContentPane().add(btnRanking);
        btnRanking.setBounds(40, 335, 340, 32);

        btnCerrar.setText("Cerrar sesion");
        btnCerrar.addActionListener(this::btnCerrarActionPerformed);
        getContentPane().add(btnCerrar);
        btnCerrar.setBounds(40, 390, 340, 32);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUsuariosActionPerformed
        new Usuarios(sesion).setVisible(true);
    }//GEN-LAST:event_btnUsuariosActionPerformed

    private void btnCategoriasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCategoriasActionPerformed
        new Categorias(sesion).setVisible(true);
    }//GEN-LAST:event_btnCategoriasActionPerformed

    private void btnPreguntasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreguntasActionPerformed
        new Preguntas(sesion).setVisible(true);
    }//GEN-LAST:event_btnPreguntasActionPerformed

    private void btnConsultasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultasActionPerformed
        new Consultas(sesion).setVisible(true);
    }//GEN-LAST:event_btnConsultasActionPerformed

    private void btnPartidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPartidaActionPerformed
        new NuevaPartida(sesion).setVisible(true);
    }//GEN-LAST:event_btnPartidaActionPerformed

    private void btnPerfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPerfilActionPerformed
        new Perfil(sesion).setVisible(true);
    }//GEN-LAST:event_btnPerfilActionPerformed

    private void btnRankingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRankingActionPerformed
        new Ranking(sesion).setVisible(true);
    }//GEN-LAST:event_btnRankingActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        // Cerrar tambien los formularios abiertos de esta sesion.
        for(java.awt.Window ventana:java.awt.Window.getWindows()) if(ventana!=this) ventana.dispose();
        dispose(); new Login().setVisible(true);
    }//GEN-LAST:event_btnCerrarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCategorias;
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnConsultas;
    private javax.swing.JButton btnPartida;
    private javax.swing.JButton btnPerfil;
    private javax.swing.JButton btnPreguntas;
    private javax.swing.JButton btnRanking;
    private javax.swing.JButton btnUsuarios;
    private javax.swing.JLabel lblSesion;
    // End of variables declaration//GEN-END:variables
}
