package respondapp;

// Datos de la persona que inicio sesion. No contiene la contrasena.
public class Usuario {
    public int id;
    public String nombre, usuario, nacimiento, email, rol;

    public boolean esAdmin() {
        return "ADMINISTRADOR".equals(rol);
    }
}
